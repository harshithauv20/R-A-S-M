import os

from ament_index_python.packages import get_package_share_directory

from launch import LaunchDescription
from launch.actions import ExecuteProcess
from launch_ros.actions import Node


def generate_launch_description():

    package_dir = get_package_share_directory(
        "proofbox_sim"
    )

    urdf_file = os.path.join(
        package_dir,
        "urdf",
        "robot.urdf"
    )

    world_file = os.path.join(
        package_dir,
        "worlds",
        "proofbox_warehouse.world"
    )

    return LaunchDescription([

        ExecuteProcess(
            cmd=[
                "gazebo",
                "--verbose",
                world_file,
                "-s",
                "libgazebo_ros_factory.so"
            ],
            output="screen"
        ),

        Node(
            package="gazebo_ros",
            executable="spawn_entity.py",

            arguments=[
                "-entity",
                "proofbox_robot",
                "-file",
                urdf_file,

                "-x",
                "10.0",
                "-y",
                "0.0",
                "-z",
                "0.4"
            ],

            output="screen"
        ),
    ])
