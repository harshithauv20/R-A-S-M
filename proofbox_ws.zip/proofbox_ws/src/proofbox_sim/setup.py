from setuptools import find_packages, setup
import os
from glob import glob

package_name = "proofbox_sim"

setup(
    name=package_name,
    version="0.0.1",
    packages=find_packages(),

    data_files=[
        (
            "share/ament_index/resource_index/packages",
            ["resource/" + package_name],
        ),

        (
            "share/" + package_name,
            ["package.xml"],
        ),

        (
            os.path.join("share", package_name, "urdf"),
            glob("urdf/*"),
        ),

        (
            os.path.join("share", package_name, "launch"),
            glob("launch/*"),
        ),

        (
            os.path.join("share", package_name, "worlds"),
            glob("worlds/*"),
        ),
    ],

    install_requires=[
        "setuptools",
    ],

    zip_safe=True,

    maintainer="arpitha",

    maintainer_email="arpithavkhanapur1226@gmail.com",

    description="ProofBox ROS 2 robot telemetry simulation",

    license="Apache-2.0",

    entry_points={
        "console_scripts": [
            "telemetry = proofbox_sim.telemetry:main",
            "bridge = proofbox_sim.bridge:main",
            "control = proofbox_sim.control:main",
        ],
    },
)
