import json
import requests

import rclpy
from rclpy.node import Node
from std_msgs.msg import String


PROOFBOX_URL = "http://10.80.79.104:3000/api/sensor"


class ProofBoxBridge(Node):

    def __init__(self):
        super().__init__("proofbox_bridge")

        self.subscription = self.create_subscription(
            String,
            "/proofbox/telemetry",
            self.telemetry_callback,
            10
        )

        self.get_logger().info(
            f"ProofBox bridge started -> {PROOFBOX_URL}"
        )

    def telemetry_callback(self, msg):

        try:
            data = json.loads(msg.data)

            response = requests.post(
                PROOFBOX_URL,
                json=data,
                timeout=5
            )

            if response.ok:
                result = response.json()

                result_data = result.get("data", {})

                self.get_logger().info(
                    f"Sent to ProofBox | "
                    f"Status={result_data.get('status')} | "
                    f"Event={result_data.get('event')}"
                )

            else:
                self.get_logger().error(
                    f"ProofBox HTTP error: {response.status_code}"
                )

        except json.JSONDecodeError as error:
            self.get_logger().error(
                f"Invalid ROS JSON: {error}"
            )

        except requests.RequestException as error:
            self.get_logger().error(
                f"Network error: {error}"
            )

        except Exception as error:
            self.get_logger().error(
                f"Bridge error: {error}"
            )


def main(args=None):

    rclpy.init(args=args)

    node = ProofBoxBridge()

    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass

    node.destroy_node()
    rclpy.shutdown()


if __name__ == "__main__":
    main()
