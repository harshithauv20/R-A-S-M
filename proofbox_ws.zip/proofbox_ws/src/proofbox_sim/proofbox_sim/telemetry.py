import json
import math

import rclpy
from rclpy.node import Node

from std_msgs.msg import String
from geometry_msgs.msg import Twist
from nav_msgs.msg import Odometry


class ProofBoxTelemetry(Node):

    def __init__(self):
        super().__init__("proofbox_telemetry")

        self.publisher = self.create_publisher(
            String,
            "/proofbox/telemetry",
            10
        )

        self.cmd_publisher = self.create_publisher(
            Twist,
            "/cmd_vel",
            10
        )

        self.odom_subscription = self.create_subscription(
            Odometry,
            "/odom",
            self.odom_callback,
            10
        )

        self.x = 10.0
        self.y = 0.0

        self.robot_speed = 0.0
        self.incident = False

        self.timer = self.create_timer(
            1.0,
            self.update
        )

        self.get_logger().info(
            "========================================"
        )

        self.get_logger().info(
            "PROOFBOX ROBOT MONITOR ONLINE"
        )

        self.get_logger().info(
            "ROBOT-001 | WAREHOUSE PATROL"
        )

        self.get_logger().info(
            "========================================"
        )

    def odom_callback(self, msg):

        self.x = msg.pose.pose.position.x
        self.y = msg.pose.pose.position.y

        self.robot_speed = math.sqrt(
            msg.twist.twist.linear.x ** 2 +
            msg.twist.twist.linear.y ** 2
        )

    def update(self):

        # Hazard / obstacle location
        hazard_x = 5.0

        distance_to_hazard = abs(
            self.x - hazard_x
        )

        command = Twist()

        # =====================================================
        # INCIDENT CONDITION
        # =====================================================

        # Trigger before the robot reaches the obstacle.
        # This guarantees the simulated emergency stop.
        if distance_to_hazard <= 2.0:

            self.incident = True

        # =====================================================
        # INCIDENT MODE
        # =====================================================

        if self.incident:

            temperature = 78.0
            humidity = 72.0

            ultrasonic_distance = 0.25

            accel_x = 2.8
            accel_y = 2.4
            accel_z = 12.5

            gyro_x = 1.8
            gyro_y = 2.1
            gyro_z = 2.5

            gas_ppm = 650

            vibration = "HIGH"
            robot_state = "STOPPED"

            # HARD STOP
            command.linear.x = 0.0
            command.linear.y = 0.0
            command.linear.z = 0.0

            command.angular.x = 0.0
            command.angular.y = 0.0
            command.angular.z = 0.0

            self.cmd_publisher.publish(command)

            self.get_logger().error(
                "========================================"
            )

            self.get_logger().error(
                "🚨 PROOFBOX INCIDENT DETECTED"
            )

            self.get_logger().error(
                "ROBOT-001"
            )

            self.get_logger().error(
                "HAZARD / OBSTACLE DETECTED"
            )

            self.get_logger().error(
                "TEMPERATURE: 78 C"
            )

            self.get_logger().error(
                "GAS: 650 ppm"
            )

            self.get_logger().error(
                "VIBRATION: HIGH"
            )

            self.get_logger().error(
                "ROBOT STATE: STOPPED"
            )

            self.get_logger().error(
                "🚨 EMERGENCY STOP ACTIVE"
            )

            self.get_logger().error(
                "========================================"
            )

        # =====================================================
        # NORMAL PATROL
        # =====================================================

        else:

            temperature = 42.0
            humidity = 45.0

            ultrasonic_distance = max(
                1.5,
                distance_to_hazard
            )

            accel_x = 0.02
            accel_y = 0.01
            accel_z = 9.81

            gyro_x = 0.01
            gyro_y = 0.02
            gyro_z = 0.01

            gas_ppm = 120

            vibration = "NORMAL"
            robot_state = "MOVING"

            # Move toward hazard
            command.linear.x = 0.5

            self.cmd_publisher.publish(command)

        # =====================================================
        # IMU CALCULATION
        # =====================================================

        acceleration_magnitude = math.sqrt(
            accel_x ** 2 +
            accel_y ** 2 +
            accel_z ** 2
        )

        gyro_magnitude = math.sqrt(
            gyro_x ** 2 +
            gyro_y ** 2 +
            gyro_z ** 2
        )

        # =====================================================
        # TELEMETRY JSON
        # =====================================================

        data = {

            "assetId": "ROBOT-001",

            "source": "GAZEBO",

            "temperature": temperature,

            "humidity": humidity,

            "ultrasonic": {
                "distance_m": round(
                    ultrasonic_distance,
                    3
                )
            },

            "imu": {

                "acceleration": {
                    "x": accel_x,
                    "y": accel_y,
                    "z": accel_z,
                    "magnitude": round(
                        acceleration_magnitude,
                        3
                    )
                },

                "gyroscope": {
                    "x": gyro_x,
                    "y": gyro_y,
                    "z": gyro_z,
                    "magnitude": round(
                        gyro_magnitude,
                        3
                    )
                }
            },

            "gas": {
                "ppm": gas_ppm
            },

            "vibration": vibration,

            "robotState": robot_state,

            "position": {
                "x": round(self.x, 3),
                "y": round(self.y, 3)
            }
        }

        message = String()

        message.data = json.dumps(data)

        self.publisher.publish(message)

        # =====================================================
        # LIVE TERMINAL
        # =====================================================

        if self.incident:

            self.get_logger().error(
                "🚨 INCIDENT | "
                "X=%.2f | "
                "TEMP=%.1fC | "
                "HUM=%.1f%% | "
                "US=%.2fm | "
                "GAS=%dppm | "
                "VIB=HIGH | "
                "STATE=STOPPED"
                % (
                    self.x,
                    temperature,
                    humidity,
                    ultrasonic_distance,
                    gas_ppm
                )
            )

        else:

            self.get_logger().info(
                "PATROL | "
                "X=%.2f | "
                "TEMP=%.1fC | "
                "HUM=%.1f%% | "
                "US=%.2fm | "
                "GAS=%dppm | "
                "VIB=NORMAL | "
                "STATE=MOVING"
                % (
                    self.x,
                    temperature,
                    humidity,
                    ultrasonic_distance,
                    gas_ppm
                )
            )


def main(args=None):

    rclpy.init(args=args)

    node = ProofBoxTelemetry()

    try:
        rclpy.spin(node)

    except KeyboardInterrupt:
        pass

    node.destroy_node()
    rclpy.shutdown()


if __name__ == "__main__":
    main()
