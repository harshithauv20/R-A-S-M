import json
import math
import select
import sys
import termios
import tty

import rclpy
from rclpy.node import Node

from geometry_msgs.msg import Twist
from nav_msgs.msg import Odometry
from std_msgs.msg import String


class ProofBoxControl(Node):

    def __init__(self):

        super().__init__("proofbox_control")

        # ==========================================
        # ROS PUBLISHERS
        # ==========================================

        self.cmd_pub = self.create_publisher(
            Twist,
            "/cmd_vel",
            10
        )

        self.telemetry_pub = self.create_publisher(
            String,
            "/proofbox/telemetry",
            10
        )

        # ==========================================
        # ODOMETRY
        # ==========================================

        self.odom_sub = self.create_subscription(
            Odometry,
            "/odom",
            self.odom_callback,
            10
        )

        self.x = 0.0
        self.y = 0.0

        # ==========================================
        # ROBOT CONTROL STATE
        # ==========================================

        self.current_key = ""

        self.speed = 0.6
        self.turn_speed = 0.9

        # ==========================================
        # SENSOR MODE
        # ==========================================

        self.alert_mode = "NORMAL"

        # ==========================================
        # TERMINAL
        # ==========================================

        self.old_settings = termios.tcgetattr(
            sys.stdin
        )

        tty.setcbreak(
            sys.stdin.fileno()
        )

        # ==========================================
        # TIMERS
        # ==========================================

        self.control_timer = self.create_timer(
            0.05,
            self.control_loop
        )

        self.telemetry_timer = self.create_timer(
            1.0,
            self.publish_telemetry
        )

        self.print_controls()

    # ==============================================
    # DISPLAY CONTROLS
    # ==============================================

    def print_controls(self):

        print("")
        print("==============================================")
        print("       PROOFBOX ROBOT LIVE CONTROL")
        print("==============================================")
        print("")
        print("MOVEMENT")
        print(" W       FORWARD")
        print(" S       BACKWARD")
        print(" A       TURN LEFT")
        print(" D       TURN RIGHT")
        print(" SPACE   STOP")
        print("")
        print("SENSOR ALERTS")
        print(" 1       NORMAL")
        print(" 2       HIGH TEMPERATURE")
        print(" 3       HIGH HUMIDITY")
        print(" 4       HIGH VIBRATION / IMU")
        print(" 5       ULTRASONIC OBSTACLE")
        print(" 6       ALL SENSOR ALERTS")
        print(" 0       CLEAR ALERT")
        print("")
        print(" Q       QUIT")
        print("")
        print("==============================================")
        print("W/A/S/D movement remains active")
        print("until another movement key or SPACE")
        print("is pressed.")
        print("==============================================")
        print("")

    # ==============================================
    # ODOMETRY
    # ==============================================

    def odom_callback(self, msg):

        self.x = msg.pose.pose.position.x
        self.y = msg.pose.pose.position.y

    # ==============================================
    # READ KEY
    # ==============================================

    def read_key(self):

        key = ""

        while True:

            ready, _, _ = select.select(
                [sys.stdin],
                [],
                [],
                0.0
            )

            if not ready:
                break

            key = sys.stdin.read(1)

        return key

    # ==============================================
    # CONTROL LOOP
    # ==============================================

    def control_loop(self):

        key = self.read_key()

        # ==========================================
        # NEW KEY PRESSED
        # ==========================================

        if key:

            key_lower = key.lower()

            # -------------------------------
            # MOVEMENT
            # -------------------------------

            if key_lower in ["w", "s", "a", "d"]:

                self.current_key = key_lower

                self.get_logger().info(
                    "Movement: %s"
                    % self.current_key.upper()
                )

            # -------------------------------
            # STOP
            # -------------------------------

            elif key == " ":

                self.current_key = ""

                self.get_logger().warn(
                    "ROBOT STOPPED"
                )

            # -------------------------------
            # NORMAL
            # -------------------------------

            elif key == "1":

                self.alert_mode = "NORMAL"

                self.get_logger().info(
                    "SENSOR MODE: NORMAL"
                )

            # -------------------------------
            # TEMPERATURE
            # -------------------------------

            elif key == "2":

                self.alert_mode = "TEMPERATURE"

                self.get_logger().warn(
                    "ALERT: HIGH TEMPERATURE"
                )

            # -------------------------------
            # HUMIDITY
            # -------------------------------

            elif key == "3":

                self.alert_mode = "HUMIDITY"

                self.get_logger().warn(
                    "ALERT: HIGH HUMIDITY"
                )

            # -------------------------------
            # VIBRATION
            # -------------------------------

            elif key == "4":

                self.alert_mode = "VIBRATION"

                self.get_logger().warn(
                    "ALERT: HIGH VIBRATION / IMU"
                )

            # -------------------------------
            # ULTRASONIC
            # -------------------------------

            elif key == "5":

                self.alert_mode = "ULTRASONIC"

                self.get_logger().warn(
                    "ALERT: ULTRASONIC OBSTACLE"
                )

            # -------------------------------
            # ALL ALERTS
            # -------------------------------

            elif key == "6":

                self.alert_mode = "ALL"

                self.current_key = ""

                self.get_logger().error(
                    "================================"
                )

                self.get_logger().error(
                    "PROOFBOX INCIDENT"
                )

                self.get_logger().error(
                    "ALL SENSOR ALERTS ACTIVE"
                )

                self.get_logger().error(
                    "ROBOT EMERGENCY STOP"
                )

                self.get_logger().error(
                    "================================"
                )

            # -------------------------------
            # CLEAR ALERT
            # -------------------------------

            elif key == "0":

                self.alert_mode = "NORMAL"

                self.get_logger().info(
                    "ALL SENSOR ALERTS CLEARED"
                )

            # -------------------------------
            # QUIT
            # -------------------------------

            elif key_lower == "q":

                raise KeyboardInterrupt

        # ==========================================
        # CREATE MOVEMENT COMMAND
        # ==========================================

        command = Twist()

        # ALL ALERTS = STOP
        if self.alert_mode == "ALL":

            command.linear.x = 0.0
            command.angular.z = 0.0

        # OTHERWISE FOLLOW CURRENT MOVEMENT KEY
        else:

            if self.current_key == "w":

                command.linear.x = self.speed
                command.angular.z = 0.0

            elif self.current_key == "s":

                command.linear.x = -self.speed
                command.angular.z = 0.0

            elif self.current_key == "a":

                command.linear.x = 0.0
                command.angular.z = self.turn_speed

            elif self.current_key == "d":

                command.linear.x = 0.0
                command.angular.z = -self.turn_speed

            else:

                command.linear.x = 0.0
                command.angular.z = 0.0

        # ==========================================
        # PUBLISH MOVEMENT
        # ==========================================

        self.cmd_pub.publish(command)

    # ==============================================
    # TELEMETRY
    # ==============================================

    def publish_telemetry(self):

        # ==========================================
        # NORMAL VALUES
        # ==========================================

        temperature = 42.0
        humidity = 45.0

        ultrasonic = 1.50

        accel_x = 0.02
        accel_y = 0.01
        accel_z = 9.81

        gyro_x = 0.01
        gyro_y = 0.02
        gyro_z = 0.01

        gas_ppm = 120

        vibration = "NORMAL"

        # ==========================================
        # SENSOR ALERTS
        # ==========================================

        if self.alert_mode == "TEMPERATURE":

            temperature = 82.0

        elif self.alert_mode == "HUMIDITY":

            humidity = 85.0

        elif self.alert_mode == "VIBRATION":

            vibration = "HIGH"

            accel_x = 3.5
            accel_y = 3.2
            accel_z = 13.0

            gyro_x = 2.5
            gyro_y = 2.4
            gyro_z = 2.8

        elif self.alert_mode == "ULTRASONIC":

            ultrasonic = 0.20

        elif self.alert_mode == "ALL":

            temperature = 82.0
            humidity = 85.0

            ultrasonic = 0.20

            accel_x = 3.5
            accel_y = 3.2
            accel_z = 13.0

            gyro_x = 2.5
            gyro_y = 2.4
            gyro_z = 2.8

            gas_ppm = 700

            vibration = "HIGH"

        # ==========================================
        # ROBOT STATE
        # ==========================================

        if self.alert_mode == "ALL":

            robot_state = "STOPPED"

        elif self.current_key in ["w", "s", "a", "d"]:

            robot_state = "MOVING"

        else:

            robot_state = "STOPPED"

        # ==========================================
        # IMU
        # ==========================================

        acceleration_magnitude = math.sqrt(
            accel_x ** 2 +
            accel_y ** 2 +
            accel_z ** 2
        )

        gyro_magnitude = math.sqrt(
            gyro_x ** 2 +
            gyro_y ** 2 +
            gyro_z ** 2
        )

        # ==========================================
        # TELEMETRY DATA
        # ==========================================

        data = {

            "assetId": "ROBOT-001",

            "source": "GAZEBO",

            "temperature": temperature,

            "humidity": humidity,

            "ultrasonic": {
                "distance_m": ultrasonic
            },

            "imu": {

                "acceleration": {
                    "x": accel_x,
                    "y": accel_y,
                    "z": accel_z,
                    "magnitude": round(
                        acceleration_magnitude,
                        3
                    )
                },

                "gyroscope": {
                    "x": gyro_x,
                    "y": gyro_y,
                    "z": gyro_z,
                    "magnitude": round(
                        gyro_magnitude,
                        3
                    )
                }
            },

            "gas": {
                "ppm": gas_ppm
            },

            "vibration": vibration,

            "robotState": robot_state,

            "position": {
                "x": round(self.x, 3),
                "y": round(self.y, 3)
            }
        }

        message = String()

        message.data = json.dumps(data)

        self.telemetry_pub.publish(message)

        # ==========================================
        # LIVE TERMINAL
        # ==========================================

        self.get_logger().info(
            "MODE=%s | "
            "KEY=%s | "
            "TEMP=%.1fC | "
            "HUM=%.1f%% | "
            "US=%.2fm | "
            "VIB=%s | "
            "STATE=%s"
            % (
                self.alert_mode,
                self.current_key.upper()
                if self.current_key
                else "STOP",
                temperature,
                humidity,
                ultrasonic,
                vibration,
                robot_state
            )
        )

    # ==============================================
    # SHUTDOWN
    # ==============================================

    def shutdown(self):

        command = Twist()

        command.linear.x = 0.0
        command.angular.z = 0.0

        self.cmd_pub.publish(command)

        termios.tcsetattr(
            sys.stdin,
            termios.TCSADRAIN,
            self.old_settings
        )


def main(args=None):

    rclpy.init(args=args)

    node = ProofBoxControl()

    try:

        rclpy.spin(node)

    except KeyboardInterrupt:

        pass

    finally:

        node.shutdown()

        node.destroy_node()

        rclpy.shutdown()


if __name__ == "__main__":

    main()
